<?php
include_once '../php/PHPLogin.inc.php';
include_once '../php/SQLVerify.inc.php';
include_once '../php/returnJson.php';
if(isset($_GET["count"]))
	    {
	$count = $_GET["count"];
	$link = loginDai();

$query ="select * from lunbo limit ".$count;
	$result = todoSQL($link, $query);
$res_array=[];
$_post=[];//
 for ($i=0; $row = $result->fetch_assoc(); $i++){
	$_post=[$i+1];//
	$res_array[$i] = $row;
	}
	echo(apiSuccess("执行成功",'200',$data=$res_array));
		}
	?>