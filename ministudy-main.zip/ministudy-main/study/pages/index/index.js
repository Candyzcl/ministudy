//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    lunbo:[
      {id:"1",picture:"/images/one.png"},
      {id:"2",picture:"/images/two.png"},
      {id:"3",picture:"/images/three.png"}
    
    ],
    common:[
      {id:"1",name:"形式与政策",type:"",picture:"../../images/three.png"},
      {id:"2",name:"大学生职业生涯规划",type:"课程",picture:"../../images/three.png"},
      {id:"3",name:"大学生职业生涯规划",type:"课程",picture:"../../images/three.png"},
      {id:"4",name:"大学生职业生涯规划",type:"课程",picture:"../../images/three.png"},
      {id:"5",name:"大学生职业生涯规划",type:"课程",picture:"../../images/three.png"}
    ],
    choiencenessbox:[
      
       {id:"1",type:"",text:"每个人都要摸索自己的读书方法，从书中去发现自己的长处……",picture:"../../images/two.png",data:"2020-11-06",review:"42",pointgood:"24",pageview:"14"},
       {id:"2",text:"每个人都要摸索自己的读书方法，从书中去发现自己的长处……",type:"",picture:"../../images/two.png",data:"2020-11-06",review:"42",pointgood:"24",pageview:"14"},
       {id:"3",text:"每个人都要摸索自己的读书方法，从书中去发现自己的长处……",type:"",picture:"../../images/three.png",data:"2020-11-06",review:"42",pointgood:"24",pageview:"14"},
      {id:"4",text:"每个人都要摸索自己的读书方法，从书中去发现自己的长处……",type:"",picture:"../../images/three.png",data:"2020-11-06",review:"42",pointgood:"24",pageview:"14"},
        {id:"5",text:"每个人都要摸索自己的读书方法，从书中去发现自己的长处……",type:"",picture:"../../images/three.png",data:"2020-11-06",review:"42",pointgood:"24",pageview:"14"},
        {id:"6",text:"每个人都要摸索自己的读书方法，从书中去发现自己的长处……",type:"",picture:"../../images/three.png",data:"2020-11-06",review:"42",pointgood:"24",pageview:"14"},
        {id:"7",text:"每个人都要摸索自己的读书方法，从书中去发现自己的长处……",type:"",picture:"../../images/three.png",data:"2020-11-06",review:"42",pointgood:"24",pageview:"14"}
    ] 
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})
